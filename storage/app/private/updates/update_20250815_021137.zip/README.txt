HF System – Minimal Update Package
==================================

Version: hello-1
Created: 2025-08-14 23:10:17

What this update does
---------------------
- Adds a harmless marker file at: public/hf_update_hello.txt
  This lets you verify the in-app updater is working end-to-end
  without changing any application logic or views.

How to apply
------------
1) Go to: /admin/update inside your HF system
2) Choose this ZIP and click "رفع الحزمة"
3) After success, check the file exists on the server:
   /var/www/hf_system/live/public/hf_update_hello.txt

Rollback note
-------------
This package does NOT alter configs, vendor, or routes.
It is safe to test the updater pipeline.