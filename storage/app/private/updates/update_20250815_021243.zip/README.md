# HF Demo Update (v1.0.0)

This archive is intentionally minimal to test the upload/unzip step.
It only includes this README and `update.json`.

If you want a real update, ask me and I'll package specific files next.